#!/bin/sh
python ../vod_recovery.py
echo
read -p "Press any key to continue..."
